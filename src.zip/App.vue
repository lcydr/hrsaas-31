<template>
  <div id="app">
    <!-- 一级占位符 -->
    <router-view />
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>
